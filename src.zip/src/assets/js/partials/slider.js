/** Scroll-snap slider with mouse-drag + arrow buttons. No dependencies. */
export default function initSliders() {
  document.querySelectorAll('[data-luxe-slider]').forEach(root => {
    if (root.__lx) return; root.__lx = true;
    const track = root.querySelector('.luxe-slider__track');
    const step = () => (track.querySelector('.luxe-slide')?.getBoundingClientRect().width || 300) + 16;
    const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
    root.querySelector('[data-slider-prev]')?.addEventListener('click', () => track.scrollBy({ left: -step() * dir, behavior: 'smooth' }));
    root.querySelector('[data-slider-next]')?.addEventListener('click', () => track.scrollBy({ left: step() * dir, behavior: 'smooth' }));
    track.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight') track.scrollBy({ left: step(), behavior: 'smooth' });
      if (e.key === 'ArrowLeft') track.scrollBy({ left: -step(), behavior: 'smooth' });
    });

    let down = false, sx = 0, sl = 0, moved = false;
    track.addEventListener('pointerdown', e => {
      if (e.pointerType !== 'mouse') return; // touch uses native scrolling
      down = true; moved = false; sx = e.clientX; sl = track.scrollLeft;
    });
    addEventListener('pointermove', e => {
      if (!down) return;
      const dx = e.clientX - sx;
      if (Math.abs(dx) > 4) { moved = true; track.classList.add('is-dragging'); }
      track.scrollLeft = sl - dx;
    });
    addEventListener('pointerup', () => {
      if (!down) return; down = false;
      track.classList.remove('is-dragging');
      if (moved) { const s = step(); track.scrollTo({ left: Math.round(track.scrollLeft / s) * s, behavior: 'smooth' }); }
    });
    track.addEventListener('click', e => { if (moved) { e.preventDefault(); moved = false; } }, true);
  });
}
