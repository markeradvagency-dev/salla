import { gsap } from 'gsap';

/**
 * Cart drawer. Uses Salla's cart API + events:
 *   salla.cart.latest(), salla.cart.details(), salla.cart.updateItem({id, quantity}), salla.cart.deleteItem(id), cart::updated
 * The header's cart icon is intercepted (capture phase) so it opens this drawer instead of navigating.
 */
export default function initCartDrawer() {
  const root = document.getElementById('luxe-cart-drawer');
  if (!root) return null;
  const $ = s => root.querySelector(s);
  const list = $('[data-drawer-items]'), empty = $('[data-drawer-empty]'), foot = $('[data-drawer-foot]');
  const bar = $('.luxe-drawer__bar');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const money = v => (window.salla && salla.money ? salla.money(v) : v);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let lastFocus = null;

  const pick = (o, ...keys) => { for (const k of keys) { const v = k.split('.').reduce((a, p) => a?.[p], o); if (v) return v; } return ''; };

  function render(cart) {
    const items = cart?.items || [];
    $('[data-drawer-count]').textContent = items.length ? `(${cart.count ?? items.length})` : '';
    empty.hidden = items.length > 0; foot.hidden = !items.length; list.hidden = !items.length;
    $('[data-drawer-total]').textContent = money(cart?.total ?? 0);

    const fs = cart?.free_shipping_bar;
    bar.hidden = !(fs && fs.minimum_amount);
    if (fs && fs.minimum_amount) {
      $('[data-drawer-bar]').style.width = Math.min(100, fs.percent || 0) + '%';
      $('[data-drawer-bar-msg]').textContent = fs.has_free_shipping
        ? (salla.lang?.get('luxe.free_shipping') || '✓')
        : `${money(fs.remaining)} → ${salla.lang?.get('luxe.free_shipping') || ''}`;
    }

    list.innerHTML = items.map(it => {
      const name = pick(it, 'product_name', 'name', 'product.name');
      const img = pick(it, 'image.url', 'image', 'product_image', 'thumbnail', 'product.image.url');
      const url = pick(it, 'url', 'product_url', 'product.url') || '#';
      const price = it.total ?? it.price;
      return `<article class="lx-item" data-id="${it.id}" data-qty="${it.quantity}">
        <a href="${esc(url)}">${img ? `<img src="${esc(img)}" alt="${esc(name)}" loading="lazy" width="76" height="96">` : '<span></span>'}</a>
        <div><h3><a href="${esc(url)}">${esc(name)}</a></h3><div class="lx-price">${money(price)}</div>
          <div class="lx-qty"><button type="button" data-act="dec" aria-label="-">−</button><span>${it.quantity}</span><button type="button" data-act="inc" aria-label="+">+</button></div></div>
        <button type="button" class="lx-rm" data-act="rm" aria-label="remove"><i class="sicon-cancel"></i></button>
      </article>`;
    }).join('');
    if (!reduced && root.classList.contains('is-open')) gsap.from(list.children, { opacity: 0, y: 16, stagger: 0.05, duration: 0.5, ease: 'power3.out', clearProps: 'all' });
  }

  async function refresh() {
    try {
      const latest = await salla.cart.latest();
      const id = latest?.data?.cart?.id ?? latest?.data?.id;
      if (!id) return render(latest?.data?.cart || latest?.data || null);
      const full = await salla.cart.details(id, ['options']);
      render(full?.data?.cart || full?.data || latest.data.cart);
    } catch (e) { render(null); }
  }

  function open() {
    lastFocus = document.activeElement;
    root.classList.add('is-open'); root.setAttribute('aria-hidden', 'false');
    document.body.classList.add('luxe-drawer-open');
    refresh();
    setTimeout(() => $('[data-drawer-close].luxe-icon-btn')?.focus(), 50);
  }
  function close() {
    root.classList.remove('is-open'); root.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('luxe-drawer-open');
    lastFocus?.focus?.();
  }

  root.addEventListener('click', async e => {
    if (e.target.closest('[data-drawer-close]')) return close();
    const btn = e.target.closest('[data-act]'); if (!btn) return;
    const row = btn.closest('.lx-item'); const id = row.dataset.id; const qty = Number(row.dataset.qty);
    row.classList.add('is-busy');
    try {
      if (btn.dataset.act === 'rm') await salla.cart.deleteItem(id);
      else await salla.cart.updateItem({ id, quantity: btn.dataset.act === 'inc' ? qty + 1 : Math.max(1, qty - 1) });
    } finally { refresh(); }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  salla.event.on('cart::updated', () => { if (root.classList.contains('is-open')) refresh(); });

  // header cart icon → drawer (capture so Salla's default navigation is skipped)
  document.addEventListener('click', e => {
    const c = e.target.closest('salla-cart-summary'); if (!c || c.closest('#luxe-cart-drawer')) return;
    e.preventDefault(); e.stopPropagation(); open();
  }, true);

  return { open, close, refresh };
}
