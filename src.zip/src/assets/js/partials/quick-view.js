/**
 * Quick view: injects a "Quick view" button over each product card image (cards are rendered by the
 * <custom-salla-product-card> web component, so we observe the DOM), then fills #luxe-quick-view from
 * salla.product.getDetails(). Falls back to normal navigation if the API call fails.
 */
export default function initQuickView() {
  const label = () => (window.salla?.lang?.get('luxe.quick_view')) || 'Quick view';
  const modal = () => document.getElementById('luxe-quick-view');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function decorate(card) {
    const holder = card.querySelector('.s-product-card-image');
    if (!holder || holder.querySelector('.luxe-qv-btn')) return;
    const id = card.id?.replace('product-', '') || card.getAttribute('product-id') || card.closest('[id^=product-]')?.id.replace('product-', '');
    if (!id) return;
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'luxe-qv-btn'; b.textContent = label(); b.dataset.qv = id;
    holder.appendChild(b);
  }
  const scan = () => document.querySelectorAll('.s-product-card-entry').forEach(decorate);
  new MutationObserver(scan).observe(document.body, { childList: true, subtree: true });
  scan();

  document.addEventListener('click', async e => {
    const b = e.target.closest('.luxe-qv-btn'); if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const href = b.closest('.s-product-card-entry')?.querySelector('a')?.href;
    try {
      const res = await salla.product.getDetails(Number(b.dataset.qv), ['images']);
      const p = res?.data || res;
      const img = p.image?.url || p.images?.[0]?.url || p.thumbnail || '';
      const price = p.is_on_sale ? p.sale_price : p.price;
      modal().querySelector('[data-qv-body]').innerHTML = `
        <div>${img ? `<img src="${esc(img)}" alt="${esc(p.name)}">` : ''}</div>
        <div class="luxe-qv__info"><h3>${esc(p.name)}</h3>
          <div class="luxe-qv__price">${salla.money(price)}</div>
          <p>${esc((p.description || '').replace(/<[^>]+>/g, '').slice(0, 220))}</p>
          <salla-add-product-button product-id="${p.id}" product-status="${esc(p.status)}" product-type="${esc(p.type)}" width="wide"></salla-add-product-button>
          <a class="luxe-btn luxe-btn--link luxe-btn--md" href="${esc(p.url || href)}"><span class="luxe-btn__label">${esc(salla.lang?.get('luxe.details') || 'Details')}</span></a>
        </div>`;
      modal().setAttribute('modal-title', '');
      modal().open();
    } catch (err) { if (href) location.href = href; }
  }, true);
}
