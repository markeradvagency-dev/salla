/**
 * Luxe motion + UI layer. Loaded on every page (deferred, after app.js).
 * GSAP core only (no ScrollTrigger): reveals use IntersectionObserver, parallax uses one rAF loop.
 */
import { gsap } from 'gsap';
import initSliders from './partials/slider';
import initCartDrawer from './partials/cart-drawer';
import initQuickView from './partials/quick-view';

const cfg = Object.assign({ animations: true, intensity: 'medium', parallax: true, pageTransition: true, cartDrawer: true, quickView: true, cursor: true }, window.luxe || {});
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const motion = cfg.animations && !reduced;
const K = { subtle: 0.6, medium: 1, bold: 1.5 }[cfg.intensity] || 1;
const EASE = 'expo.out';

const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

/* ---------- text split: words wrapped for a masked slide-up ---------- */
function splitWords(el) {
  if (el.classList.contains('lx-split')) return [];
  const text = el.textContent.trim();
  el.setAttribute('aria-label', text);
  el.textContent = '';
  const inners = text.split(/\s+/).map(word => {
    const w = document.createElement('span'); w.className = 'lx-w'; w.setAttribute('aria-hidden', 'true');
    const i = document.createElement('span'); i.textContent = word; w.appendChild(i); el.appendChild(w);
    return i;
  });
  el.classList.add('lx-split');
  return inners;
}

/* ---------- reveal on scroll ---------- */
function initReveal() {
  const targets = $$('.luxe-reveal');
  if (!targets.length) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target; io.unobserve(el);
      gsap.to(el, { opacity: 1, y: 0, duration: 1 * K, ease: EASE, delay: parseFloat(el.dataset.revealDelay) || 0, clearProps: 'transform,willChange' });
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
  targets.forEach(t => io.observe(t));
}

/* ---------- split headings reveal (hero on load, others on scroll) ---------- */
function initSplit() {
  $$('[data-split]').forEach(el => {
    const words = splitWords(el);
    if (!words.length) return;
    gsap.set(words, { yPercent: 110 });
    const play = () => gsap.to(words, { yPercent: 0, duration: 1.1 * K, ease: EASE, stagger: 0.06 });
    if (el.closest('.luxe-hero')) return el.__lxPlay = play;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { io.disconnect(); play(); } }, { threshold: 0.3 });
    io.observe(el);
  });
}

/* ---------- hero entrance ---------- */
function heroIntro() {
  const hero = document.querySelector('.luxe-hero');
  const tl = gsap.timeline({ defaults: { ease: EASE } });
  if (hero) {
    tl.fromTo('.luxe-hero__arch', { clipPath: 'inset(100% 0% 0% 0% round 999px 999px 24px 24px)' }, { clipPath: 'inset(0% 0% 0% 0% round 999px 999px 24px 24px)', duration: 1.5 * K, clearProps: 'clipPath' }, 0);
    tl.to('[data-hero="visual"]', { opacity: 1, duration: 0.2 }, 0);
    tl.from('.luxe-hero__arch img', { scale: 1.3, duration: 2 * K }, 0);
    tl.from('.luxe-hero__badge', { scale: 0, rotate: -120, duration: 1.1 * K, ease: 'back.out(1.6)' }, 0.9);
    tl.from('.luxe-hero__chip', { y: 30, opacity: 0, duration: 0.9 * K }, 1.1);
    tl.from('.luxe-hero__blob', { scale: 0.6, opacity: 0, duration: 1.8 * K }, 0);
    const title = hero.querySelector('[data-split]');
    tl.add(() => title && title.__lxPlay && title.__lxPlay(), 0.15);
    tl.to('[data-hero="fade"]', { opacity: 1, y: 0, duration: 1 * K, stagger: 0.12, clearProps: 'transform' }, 0.45);
  }
  if (cfg.pageTransition) {
    tl.from('.luxe-header', { y: -24, opacity: 0, duration: 0.9 * K, clearProps: 'all' }, 0);
    if (!hero) tl.from('main > *:first-child', { opacity: 0, y: 16, duration: 0.8 * K, clearProps: 'all' }, 0.1);
  }
}

/* ---------- parallax: single rAF, only visible elements ---------- */
function initParallax() {
  if (!cfg.parallax) return;
  const items = $$('[data-parallax], [data-parallax-img]').map(el => ({ el, speed: parseFloat(el.dataset.parallax) || (el.hasAttribute('data-parallax-img') ? 0.06 : 0.2), set: gsap.quickSetter(el, 'y', 'px'), vis: false }));
  if (!items.length) return;
  const io = new IntersectionObserver(es => es.forEach(e => { items.find(i => i.el === e.target).vis = e.isIntersecting; }), { rootMargin: '10% 0px' });
  items.forEach(i => io.observe(i.el.parentElement));
  items.forEach(i => { i.host = i.el.parentElement; });
  let ticking = false;
  const update = () => {
    ticking = false;
    const vh = innerHeight;
    items.forEach(i => {
      if (!i.vis) return;
      const r = i.host.getBoundingClientRect();
      i.set(((r.top + r.height / 2) - vh / 2) * -i.speed * K);
    });
  };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
  addEventListener('resize', update);
  update();
}

/* ---------- magnetic buttons (pointer devices only) ---------- */
function initMagnetic() {
  if (!matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  $$('.luxe-magnetic').forEach(b => {
    const x = gsap.quickTo(b, 'x', { duration: 0.5, ease: 'power3.out' });
    const y = gsap.quickTo(b, 'y', { duration: 0.5, ease: 'power3.out' });
    b.addEventListener('pointermove', e => { const r = b.getBoundingClientRect(); x((e.clientX - r.left - r.width / 2) * 0.18); y((e.clientY - r.top - r.height / 2) * 0.28); });
    b.addEventListener('pointerleave', () => { x(0); y(0); });
  });
}

/* ---------- product-card stagger: cards render async (web component) ---------- */
function initCardObserver() {
  const seen = new WeakSet();
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return; io.unobserve(e.target);
    gsap.fromTo(e.target, { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.9 * K, ease: EASE, clearProps: 'all' });
  }), { threshold: 0.05 });
  const scan = () => $$('salla-products-list custom-salla-product-card, .s-products-list-wrapper > *').forEach(c => { if (!seen.has(c)) { seen.add(c); c.style.opacity = 0; io.observe(c); } });
  new MutationObserver(scan).observe(document.body, { childList: true, subtree: true });
  scan();
}

/* ---------- menu transitions: animate dropdown/mega panels on hover ---------- */
function initMenu() {
  if (!matchMedia('(hover: hover)').matches) return;
  document.addEventListener('mouseover', e => {
    const li = e.target.closest && e.target.closest('.root-level.has-children');
    if (!li || li.__lxOn) return; li.__lxOn = true;
    const panel = li.querySelector('.sub-menu, .mega-menu');
    if (panel) gsap.fromTo(panel, { y: 12, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45, ease: 'power3.out', clearProps: 'transform' });
    li.addEventListener('mouseleave', () => { li.__lxOn = false; }, { once: true });
  });
}

/* ---------- count-up numbers ---------- */
function initCounters() {
  $$('[data-count]').forEach(el => {
    const raw = el.dataset.count; const n = parseFloat(raw.replace(/[^\d.]/g, '')); if (isNaN(n)) return;
    const suffix = raw.replace(/[\d.,\s]/g, '');
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return; io.disconnect();
      const o = { v: 0 };
      gsap.to(o, { v: n, duration: 2 * K, ease: 'power3.out', onUpdate: () => { el.textContent = Math.round(o.v).toLocaleString(document.documentElement.lang || 'en') + suffix; } });
    }, { threshold: 0.6 });
    io.observe(el);
  });
}

/* ---------- custom cursor (fine pointers only) ---------- */
function initCursor() {
  if (!cfg.cursor || !matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  const c = document.createElement('div'); c.className = 'luxe-cursor'; c.setAttribute('aria-hidden', 'true'); document.body.appendChild(c);
  const x = gsap.quickTo(c, 'x', { duration: 0.35, ease: 'power3.out' });
  const y = gsap.quickTo(c, 'y', { duration: 0.35, ease: 'power3.out' });
  addEventListener('pointermove', e => { x(e.clientX); y(e.clientY); }, { passive: true });
  document.addEventListener('pointerover', e => {
    const t = e.target.closest && e.target.closest('[data-cursor], a, button, [role=button], input, .luxe-slider__track');
    const label = t && t.closest('[data-cursor]')?.dataset.cursor;
    c.classList.toggle('is-link', !!label); c.classList.toggle('is-small', !!t && !label);
    c.textContent = label || '';
  });
  document.addEventListener('pointerleave', () => { c.style.opacity = 0; });
  document.addEventListener('pointerenter', () => { c.style.opacity = 1; });
}

/* ---------- add-to-cart feedback ---------- */
function initCartFeedback() {
  const bump = () => document.querySelectorAll('.luxe-cart-icon').forEach(el => { el.classList.remove('luxe-cart-bump'); void el.offsetWidth; el.classList.add('luxe-cart-bump'); });
  if (window.salla) {
    salla.cart.event.onItemAdded(() => { bump(); if (cfg.cartDrawer && window.luxeCartDrawer) window.luxeCartDrawer.open(); });
  }
}

function boot() {
  window.__lxOk = true;
  initSliders();
  if (cfg.cartDrawer) window.luxeCartDrawer = initCartDrawer();
  if (cfg.quickView) initQuickView();
  initCartFeedback();
  if (!motion) { document.body.classList.remove('lx-ready'); initCursor(); return; }
  initSplit();
  initReveal();
  initParallax();
  initMagnetic();
  initCardObserver();
  initMenu();
  initCounters();
  initCursor();
  heroIntro();
}

const start = () => (window.salla ? salla.onReady(boot) : boot());
document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', start) : start();
